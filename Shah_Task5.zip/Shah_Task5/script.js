const counterFormArea = document.querySelector('.form-area');
const counterForm = document.getElementById('counter-form');
const counterEl = document.getElementById('counter');
const counterTitleEl = document.getElementById('counter-title');
const timeElements = document.querySelectorAll('.counter ul li span');
const counterResetBtn = document.getElementById('counter-reset');
const complete = document.getElementById('complete');
const completeInfo = document.getElementById('complete-info');
const completeBtn = document.getElementById('complete-button');

const datePicker = document.getElementById('counter-date');

let countdownValue; // Target date in timestamp format
let countdownActive;

const second = 1000;
const minute = second * 60;
const hour = minute * 60;
const day = hour * 24;

let title = '';
let date = '';

let today = new Date().toISOString().split('T')[0];

// Allow past dates to be selected
datePicker.setAttribute('min', '1900-01-01'); // Allow dates from January 1, 1900

// Update countdown every second
function updateDom() {
  countdownActive = setInterval(() => {
    let now = new Date().getTime(); // Current time in milliseconds
    let distance = countdownValue - now; // Calculate the difference

    const days = Math.floor(distance / day);
    const hours = Math.floor((distance % day) / hour);
    const minutes = Math.floor((distance % hour) / minute);
    const seconds = Math.floor((distance % minute) / second);

    if (distance < 0) {
      clearInterval(countdownActive);
      counterEl.hidden = true;
      counterFormArea.hidden = true;
      complete.hidden = false;
      completeInfo.textContent = `${title} was finished on ${date}`;
    } else {
      timeElements[0].textContent = days;
      timeElements[1].textContent = hours;
      timeElements[2].textContent = minutes;
      timeElements[3].textContent = seconds;

      counterTitleEl.textContent = title; // Set the title dynamically
      counterFormArea.hidden = true;
      counterEl.hidden = false;
    }
  }, 1000); // Update every second
}

// Handle form submission
function updateCountdown(e) {
  e.preventDefault();

  title = e.srcElement[0].value;
  date = e.srcElement[1].value;

  if (date === '') {
    alert('Please enter a date!');
  } else {
    countdownValue = new Date(date).getTime(); // Convert date to timestamp
    localStorage.setItem('countdown', JSON.stringify({ title, date })); // Save to localStorage
    updateDom(); // Start the countdown
  }
}

// Reset countdown
function reset() {
  localStorage.removeItem('countdown');
  counterEl.hidden = true;
  complete.hidden = true;
  counterFormArea.hidden = false;
  title = '';
  date = '';
  clearInterval(countdownActive);
}

// Restore previous countdown if available in localStorage
function restoreCountdown() {
  if (localStorage.getItem('countdown')) {
    let countdownData = JSON.parse(localStorage.getItem('countdown'));
    title = countdownData.title;
    date = countdownData.date;
    countdownValue = new Date(date).getTime();
    updateDom();
  }
}

counterForm.addEventListener('submit', updateCountdown);
counterResetBtn.addEventListener('click', reset);
completeBtn.addEventListener('click', reset);

// Restore countdown from localStorage on page load (if any)
restoreCountdown();
